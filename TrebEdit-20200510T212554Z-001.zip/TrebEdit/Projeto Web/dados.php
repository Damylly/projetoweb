<?php 

	if(isset($_POST['enviar'])){
	//recebe os valores do form e armazena nas variáveis correspondentes.
	$id = $_POST['id'];
	$nome = $_POST['nome'];
	$telefone = $_POST['telefone'];
	include 'conexao.php';

	mysqli_select_db($conexao,"Pessoa")
	or die( "falha na seleção");

	$sqlInsere = "INSERT INTO tb_Pessoa(nome, telefone) 
			VALUES('$nome','$telefone')";
	if(mysqli_query($conexao,$sqlInsere)) {
	echo"<br>";	echo "Cadastro realizado com sucesso!!";echo "</br>";
     
	}
	else{
	 echo "<h3>Erro: </h3>".mysqli_error();
	}
	 
	mysqli_close($conexao);
	}

	?>
	<br>
	<a href="exemplo.php">Verificar</a>
