<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "banco";

$conexao = mysqli_connect($servidor,$usuario,$senha,$banco);

	if (mysqli_connect_errno($conexao)) {
		mysqli_connect_error();
	}else {?>
	<center><h2 style="background-color:black;color:white"><?php echo"<b>"; echo "Dados inseridos com sucesso";echo"<b>";?></h2></center>
		<?php
}
?>
